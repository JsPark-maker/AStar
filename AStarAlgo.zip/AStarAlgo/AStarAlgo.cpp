﻿#define _CRT_SECURE_NO_WARNINGS
#include "framework.h"
#include "AStarAlgo.h"
#include <process.h>
#define MAX_LOADSTRING 100
#define START_POSITION 30
#define X_PIXEL 42
#define Y_PIXEL 20
#define PIXEL_WIDTH 32
//==============================================================================
#define NOTHING  0
#define OBSTACLE 1
#define STARTPOINT 2
#define ENDPOINT 3
#define ISOPEN 4
#define ISCLOSE 5

struct stNODE;
HINSTANCE hInst;                                // 현재 인스턴스입니다.
HWND hWnd;
WCHAR szTitle[MAX_LOADSTRING];                  // 제목 표시줄 텍스트입니다.
WCHAR szWindowClass[MAX_LOADSTRING];            // 기본 창 클래스 이름입니다.

// 이 코드 모듈에 포함된 함수의 선언을 전달합니다:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
void OpenListAdd(stNODE*);
void CloseListAdd(stNODE*);
void OpenListDelete(stNODE*);
void CloseListDelete(stNODE*);
void SortOpenList();
bool SetGHF(stNODE*, bool);
bool GetXYpos(int* xPos, int* yPos);
void PathFind();
//한 픽셀의 크기 32 * 32
BYTE g_ScreenBuffer[X_PIXEL][Y_PIXEL] = { NOTHING };

struct NODELIST
{
    stNODE* data = nullptr;
    NODELIST* next = nullptr;
    NODELIST* prev = nullptr;
};

struct stNODE
{
    int Xpos = NULL;
    int Ypos = NULL;
    stNODE* prev = nullptr;
    float G = NULL;
    float H = NULL;
    float F = NULL;

};

NODELIST* g_OpenList;
NODELIST* g_CloseList;

stNODE* g_StartNode;
stNODE* g_EndNode;

bool g_PathFindComplete;

void MakeConsole()
{
    AllocConsole();
    freopen("CONOUT$", "wt", stdout);
}


int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_ASTARALGO, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // 애플리케이션 초기화를 수행합니다:
    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    }

    MakeConsole();

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_ASTARALGO));

    MSG msg;

    g_OpenList = new NODELIST;
    g_CloseList = new NODELIST;

    // 기본 메시지 루프입니다:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int) msg.wParam;
}

ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_ASTARALGO));
    wcex.hCursor        = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = MAKEINTRESOURCEW(IDC_ASTARALGO);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // 인스턴스 핸들을 전역 변수에 저장합니다.

   hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

unsigned WINAPI PathFind(PVOID p)
{
    if (g_StartNode == nullptr || g_EndNode == nullptr)
        return 1;

    int Xdistance = g_StartNode->Xpos - g_EndNode->Xpos;
    if (Xdistance < 0)
        Xdistance *= -1;

    int Ydistance = g_StartNode->Ypos - g_EndNode->Ypos;
    if (Ydistance < 0)
        Ydistance *= -1;

    g_StartNode->G = 0;
    g_StartNode->H = Xdistance + Ydistance;
    g_StartNode->F = g_StartNode->G + g_StartNode->H;

    stNODE* currentNode = g_StartNode;
    OpenListAdd(currentNode);
    for (;;)
    {
        //OpenListAdd(currentNode);
        //오픈리스트를 열고자하는 곳에 장애물이 없거나 버퍼를 벗어나지 않았거나 열려있는 상태가 아니거나 닫혀있는 상태가 아닌경우
        if (currentNode->Xpos + 1 < X_PIXEL &&
            (g_ScreenBuffer[currentNode->Xpos + 1][currentNode->Ypos] == NOTHING || g_ScreenBuffer[currentNode->Xpos + 1][currentNode->Ypos] == ENDPOINT))
        {
            stNODE* newOpenNode = new stNODE;
            newOpenNode->Xpos = currentNode->Xpos + 1;
            newOpenNode->Ypos = currentNode->Ypos;
            
            newOpenNode->prev = currentNode;
            g_ScreenBuffer[newOpenNode->Xpos][newOpenNode->Ypos] = ISOPEN;
            SetGHF(newOpenNode, false);
            for (NODELIST* nodePtr = g_OpenList->next; nodePtr != nullptr; nodePtr = nodePtr->next)
            {
                if (nodePtr->data->prev == newOpenNode->prev && nodePtr->data->G < newOpenNode->G)
                {
                    newOpenNode->prev = nodePtr->data;
                }
            }
            OpenListAdd(newOpenNode);
        }

        if (currentNode->Xpos + 1 < X_PIXEL && currentNode->Ypos + 1 < Y_PIXEL &&
            (g_ScreenBuffer[currentNode->Xpos + 1][currentNode->Ypos + 1] == NOTHING || g_ScreenBuffer[currentNode->Xpos + 1][currentNode->Ypos + 1] == ENDPOINT))
        {
            stNODE* newOpenNode = new stNODE;
            newOpenNode->Xpos = currentNode->Xpos + 1;
            newOpenNode->Ypos = currentNode->Ypos + 1;
            newOpenNode->prev = currentNode;
            g_ScreenBuffer[newOpenNode->Xpos][newOpenNode->Ypos] = ISOPEN;
            SetGHF(newOpenNode, true);
            for (NODELIST* nodePtr = g_OpenList->next; nodePtr != nullptr; nodePtr = nodePtr->next)
            {
                if (nodePtr->data->prev == newOpenNode->prev && nodePtr->data->G < newOpenNode->G)
                {
                    newOpenNode->prev = nodePtr->data;
                }
            }
            OpenListAdd(newOpenNode);
        }

        if (currentNode->Ypos + 1 < Y_PIXEL &&
            (g_ScreenBuffer[currentNode->Xpos][currentNode->Ypos + 1] == NOTHING || g_ScreenBuffer[currentNode->Xpos][currentNode->Ypos + 1] == ENDPOINT))
        {
            stNODE* newOpenNode = new stNODE;
            newOpenNode->Xpos = currentNode->Xpos;
            newOpenNode->Ypos = currentNode->Ypos + 1;
            newOpenNode->prev = currentNode;
            g_ScreenBuffer[newOpenNode->Xpos][newOpenNode->Ypos] = ISOPEN;
            SetGHF(newOpenNode, false);
            for (NODELIST* nodePtr = g_OpenList->next; nodePtr != nullptr; nodePtr = nodePtr->next)
            {
                if (nodePtr->data->prev == newOpenNode->prev && nodePtr->data->G < newOpenNode->G)
                {
                    newOpenNode->prev = nodePtr->data;
                }
            }
            OpenListAdd(newOpenNode);
        }

        if (currentNode->Ypos + 1 < Y_PIXEL && currentNode->Xpos - 1 >= 0 &&
            (g_ScreenBuffer[currentNode->Xpos - 1][currentNode->Ypos + 1] == NOTHING || g_ScreenBuffer[currentNode->Xpos - 1][currentNode->Ypos + 1] == ENDPOINT))
        {
            stNODE* newOpenNode = new stNODE;
            newOpenNode->Xpos = currentNode->Xpos - 1;
            newOpenNode->Ypos = currentNode->Ypos + 1;
            newOpenNode->prev = currentNode;
            g_ScreenBuffer[newOpenNode->Xpos][newOpenNode->Ypos] = ISOPEN;
            SetGHF(newOpenNode, true);
            for (NODELIST* nodePtr = g_OpenList->next; nodePtr != nullptr; nodePtr = nodePtr->next)
            {
                if (nodePtr->data->prev == newOpenNode->prev && nodePtr->data->G < newOpenNode->G)
                {
                    newOpenNode->prev = nodePtr->data;
                }
            }
            OpenListAdd(newOpenNode);
        }

        if (currentNode->Xpos - 1 >= 0 &&
            (g_ScreenBuffer[currentNode->Xpos - 1][currentNode->Ypos] == NOTHING || g_ScreenBuffer[currentNode->Xpos - 1][currentNode->Ypos] == ENDPOINT))
        {
            stNODE* newOpenNode = new stNODE;
            newOpenNode->Xpos = currentNode->Xpos - 1;
            newOpenNode->Ypos = currentNode->Ypos;
            newOpenNode->prev = currentNode;
            g_ScreenBuffer[newOpenNode->Xpos][newOpenNode->Ypos] = ISOPEN;
            SetGHF(newOpenNode, false);
            for (NODELIST* nodePtr = g_OpenList->next; nodePtr != nullptr; nodePtr = nodePtr->next)
            {
                if (nodePtr->data->prev == newOpenNode->prev && nodePtr->data->G < newOpenNode->G)
                {
                    newOpenNode->prev = nodePtr->data;
                }
            }
            OpenListAdd(newOpenNode);
        }

        if (currentNode->Xpos - 1 >= 0 && currentNode->Ypos - 1 >= 0 &&
            (g_ScreenBuffer[currentNode->Xpos - 1][currentNode->Ypos - 1] == NOTHING || g_ScreenBuffer[currentNode->Xpos - 1][currentNode->Ypos - 1] == ENDPOINT))
        {
            stNODE* newOpenNode = new stNODE;
            newOpenNode->Xpos = currentNode->Xpos - 1;
            newOpenNode->Ypos = currentNode->Ypos - 1;
            newOpenNode->prev = currentNode;
            g_ScreenBuffer[newOpenNode->Xpos][newOpenNode->Ypos] = ISOPEN;
            SetGHF(newOpenNode, true);
            for (NODELIST* nodePtr = g_OpenList->next; nodePtr != nullptr; nodePtr = nodePtr->next)
            {
                if (nodePtr->data->prev == newOpenNode->prev && nodePtr->data->G < newOpenNode->G)
                {
                    newOpenNode->prev = nodePtr->data;
                }
            }
            OpenListAdd(newOpenNode);
        }

        if (currentNode->Ypos - 1 >= 0 &&
            (g_ScreenBuffer[currentNode->Xpos][currentNode->Ypos - 1] == NOTHING || g_ScreenBuffer[currentNode->Xpos][currentNode->Ypos - 1] == ENDPOINT))
        {
            stNODE* newOpenNode = new stNODE;
            newOpenNode->Xpos = currentNode->Xpos;
            newOpenNode->Ypos = currentNode->Ypos - 1;
            newOpenNode->prev = currentNode;
            g_ScreenBuffer[newOpenNode->Xpos][newOpenNode->Ypos] = ISOPEN;
            SetGHF(newOpenNode, false);
            for (NODELIST* nodePtr = g_OpenList->next; nodePtr != nullptr; nodePtr = nodePtr->next)
            {
                if (nodePtr->data->prev == newOpenNode->prev && nodePtr->data->G < newOpenNode->G)
                {
                    newOpenNode->prev = nodePtr->data;
                }
            }
            OpenListAdd(newOpenNode);
        }

        if (currentNode->Xpos + 1 < X_PIXEL && currentNode->Ypos - 1 >= 0 &&
            (g_ScreenBuffer[currentNode->Xpos + 1][currentNode->Ypos - 1] == NOTHING || g_ScreenBuffer[currentNode->Xpos + 1][currentNode->Ypos - 1] == ENDPOINT))
        {
            stNODE* newOpenNode = new stNODE;
            newOpenNode->Xpos = currentNode->Xpos + 1;
            newOpenNode->Ypos = currentNode->Ypos - 1;
            newOpenNode->prev = currentNode;
            g_ScreenBuffer[newOpenNode->Xpos][newOpenNode->Ypos] = ISOPEN;
            SetGHF(newOpenNode, true);
            for (NODELIST* nodePtr = g_OpenList->next; nodePtr != nullptr; nodePtr = nodePtr->next)
            {
                if (nodePtr->data->prev == newOpenNode->prev && nodePtr->data->G < newOpenNode->G)
                {
                    newOpenNode->prev = nodePtr->data;
                }
            }
            OpenListAdd(newOpenNode);
        }

        CloseListAdd(currentNode);
        g_ScreenBuffer[currentNode->Xpos][currentNode->Ypos] = ISCLOSE;

        OpenListDelete(currentNode);
        
        

        //오름차순으로 정렬
        SortOpenList();

        /*if (currentNode->Xpos == g_EndNode->Xpos && currentNode->Ypos == g_EndNode->Ypos)
        {
            InvalidateRect(hWnd, NULL, FALSE);
            HDC hdc = GetDC(hWnd);
            printf("ASDF xPos -> %d yPos -> %d\n", g_EndNode->Xpos, g_EndNode->Ypos);
            for (stNODE* nodePtr = currentNode; nodePtr->prev != nullptr; nodePtr = nodePtr->prev)
            {
                MoveToEx(hdc, nodePtr->Xpos* PIXEL_WIDTH + PIXEL_WIDTH / 2 + 30, nodePtr->Ypos* PIXEL_WIDTH + PIXEL_WIDTH / 2 + 30, NULL);
                LineTo(hdc, nodePtr->prev->Xpos* PIXEL_WIDTH + PIXEL_WIDTH / 2 + 30, nodePtr->prev->Ypos* PIXEL_WIDTH + PIXEL_WIDTH / 2 + 30);
            }
            ReleaseDC(hWnd, hdc);
            break;
        }*/

        if (g_OpenList->next->data->Xpos == g_EndNode->Xpos && g_OpenList->next->data->Ypos == g_EndNode->Ypos)
        {
            g_EndNode->prev = currentNode;
            InvalidateRect(hWnd, NULL, FALSE);
            break;
        }

        currentNode = g_OpenList->next->data;

        InvalidateRect(hWnd, NULL, FALSE);

        Sleep(10);
    }
    return 1;
}

HBRUSH hGrayBrush;
HBRUSH hWhiteBrush;
HBRUSH hRedBrush;
HBRUSH hGreenBrush;
HBRUSH hYellowBrush;
HBRUSH hPurpleBrush;
HBRUSH 밝은시안;
HBRUSH 창백한녹색;
HBRUSH 숲녹색;
HPEN hPenForLine;
HWND hButtonPathFind;
#define PATHFIND 10

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    static bool isLBClick = false;
    static char mode = NOTHING;
    switch (message)
    {
    case WM_CREATE:
        hGrayBrush = CreateSolidBrush(RGB(178, 178, 178));
        hWhiteBrush = CreateSolidBrush(RGB(255, 255, 255));
        hRedBrush = CreateSolidBrush(RGB(255, 0, 0));
        hGreenBrush = CreateSolidBrush(RGB(0, 255, 0));
        hYellowBrush = CreateSolidBrush(RGB(255, 255, 0));
        hPurpleBrush = CreateSolidBrush(RGB(139, 0, 255));
        hButtonPathFind = CreateWindow(L"button", L"PATHFIND", WS_CHILD | WS_VISIBLE | WS_BORDER, 650, 0, 100, 30, hWnd, (HMENU)PATHFIND, hInst, NULL);
        hPenForLine = CreatePen(PS_SOLID, 3, RGB(255, 204, 0));
        밝은시안 = CreateSolidBrush(RGB(224, 255, 255));
        창백한녹색 = CreateSolidBrush(RGB(152, 251, 152));
        숲녹색 = CreateSolidBrush(RGB(34, 139, 34));
        break;
    case WM_COMMAND:
        {
            int wmId = LOWORD(wParam);
            printf("command\n");
            switch (wmId)
            {
            case IDM_EXIT:
                DestroyWindow(hWnd);
                break;
            case PATHFIND:
                _beginthreadex(
                    NULL,
                    NULL,
                    PathFind,
                    NULL,
                    NULL,
                    NULL
                );
                //PathFind();
                SetFocus(hWnd);
                break;
            default:
                return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }
        break;
    case WM_PAINT:
        {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            int startY = START_POSITION;
            for (int i = 0; i < Y_PIXEL; i++)
            {
                for (int j = 0; j < X_PIXEL; j++)
                {
                    char pixelProperty = g_ScreenBuffer[j][i];
                    if (pixelProperty == OBSTACLE)
                        SelectObject(hdc, hGrayBrush);
                    else if (pixelProperty == STARTPOINT)
                        SelectObject(hdc, hRedBrush);
                    else if (pixelProperty == ENDPOINT)
                        SelectObject(hdc, 숲녹색);
                    else if (pixelProperty == NOTHING)
                        SelectObject(hdc, hWhiteBrush);
                    else if (pixelProperty == ISOPEN)
                        SelectObject(hdc, 창백한녹색);
                    else if (pixelProperty == ISCLOSE)
                        SelectObject(hdc, 밝은시안);

                    Rectangle(hdc, 30 + (32 * j), startY, 30 + (32 * (j + 1)), startY + 32);
                }
                startY += 32;
            }

            if (g_EndNode != nullptr && g_EndNode->prev != nullptr)
            {
                SelectObject(hdc, hRedBrush);
                Rectangle(hdc, 30 + (32 * g_StartNode->Xpos), 30 + (32 * g_StartNode->Ypos), 30 + (32 * (g_StartNode->Xpos + 1)), 30 + (32 * (g_StartNode->Ypos + 1)));
                SelectObject(hdc, 숲녹색);
                Rectangle(hdc, 30 + (32 * g_EndNode->Xpos), 30 + (32 * g_EndNode->Ypos), 30 + (32 * (g_EndNode->Xpos + 1)), 30 + (32 * (g_EndNode->Ypos + 1)));
                SelectObject(hdc, hPenForLine);
                for (stNODE* nodePtr = g_EndNode; nodePtr->prev != nullptr; nodePtr = nodePtr->prev)
                {
                    MoveToEx(hdc, nodePtr->Xpos * PIXEL_WIDTH + PIXEL_WIDTH / 2 + 30, nodePtr->Ypos * PIXEL_WIDTH + PIXEL_WIDTH / 2 + 30, NULL);
                    LineTo(hdc, nodePtr->prev->Xpos * PIXEL_WIDTH + PIXEL_WIDTH / 2 + 30, nodePtr->prev->Ypos * PIXEL_WIDTH + PIXEL_WIDTH / 2 + 30);
                }
            }
            
            EndPaint(hWnd, &ps);
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    case WM_LBUTTONDOWN:
        isLBClick = true;
        {
            int Xpos = GET_X_LPARAM(lParam);
            int Ypos = GET_Y_LPARAM(lParam);

            if (!GetXYpos(&Xpos, &Ypos))
                return DefWindowProc(hWnd, message, wParam, lParam);

            if (mode == STARTPOINT)
            {
                if (g_StartNode == nullptr)//한번도 할당되지않았을경우 동적할당
                {
                    g_StartNode = new stNODE;

                    if (g_ScreenBuffer[Xpos][Ypos] == NOTHING)
                    {
                        g_StartNode->Xpos = Xpos;
                        g_StartNode->Ypos = Ypos;

                        g_ScreenBuffer[Xpos][Ypos] = STARTPOINT;
                    }
                }
                else
                {
                    if (g_ScreenBuffer[Xpos][Ypos] == NOTHING)
                    {
                        g_ScreenBuffer[g_StartNode->Xpos][g_StartNode->Ypos] = NOTHING;
                        g_StartNode->Xpos = Xpos;
                        g_StartNode->Ypos = Ypos;
                        g_ScreenBuffer[Xpos][Ypos] = STARTPOINT;
                    }
                }
            }
            else if (mode == ENDPOINT)
            {
                if (g_EndNode == nullptr)//한번도 할당되지않았을경우 동적할당
                {
                    g_EndNode = new stNODE;

                    if (g_ScreenBuffer[Xpos][Ypos] == NOTHING)
                    {
                        g_EndNode->Xpos = Xpos;
                        g_EndNode->Ypos = Ypos;

                        g_ScreenBuffer[Xpos][Ypos] = ENDPOINT;
                    }
                }
                else
                {
                    if (g_ScreenBuffer[Xpos][Ypos] == NOTHING)
                    {
                        g_ScreenBuffer[g_EndNode->Xpos][g_EndNode->Ypos] = NOTHING;
                        g_EndNode->Xpos = Xpos;
                        g_EndNode->Ypos = Ypos;
                        g_ScreenBuffer[Xpos][Ypos] = ENDPOINT;
                    }
                }
            }
            else
            {
                g_ScreenBuffer[Xpos][Ypos] = mode;
            }

            InvalidateRect(hWnd, NULL, FALSE);
        }
        break;
    case WM_LBUTTONUP:
        isLBClick = false;
        break;
    case WM_MOUSEMOVE:
        if (isLBClick && (mode == OBSTACLE || mode == NOTHING))
        {
            int Xpos = GET_X_LPARAM(lParam);
            int Ypos = GET_Y_LPARAM(lParam);
            if(!GetXYpos(&Xpos, &Ypos))
                return DefWindowProc(hWnd, message, wParam, lParam);

            g_ScreenBuffer[Xpos][Ypos] = mode;
            InvalidateRect(hWnd, NULL, FALSE);
        }
        break;
    case WM_CHAR:
    {
        
        WCHAR text[20] = { 0 };
        if (wParam == 113)//Q
        {
            mode = STARTPOINT;
            wsprintfW(text, L"STARTPOINT     ");
        }
        else if (wParam == 119)//W
        {
            mode = ENDPOINT;
            wsprintfW(text, L"ENDPOINT     ");
        }
        else if (wParam == 101)//E
        {
            mode = OBSTACLE;
            wsprintfW(text, L"OBSTACLE     ");
        }
        else if (wParam == 114)//R
        {
            mode = NOTHING;
            wsprintfW(text, L"ERASE           ");
        }
            HDC hdc = GetDC(hWnd);
            TextOut(hdc, 30, 12, text, wcslen(text));
            ReleaseDC(hWnd, hdc);
    }
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}


bool GetXYpos(int* xPos, int* yPos)
{
    for (int i = 0; i <= X_PIXEL; i++)
    {
        if (START_POSITION + (PIXEL_WIDTH * i) > *xPos)
        {
            *xPos = i - 1;
            break;
        }
        //X의 범위가 밖으로 벗어났다.
        if (i == X_PIXEL)
            return false;
    }

    for (int i = 0; i <= Y_PIXEL; i++)
    {
        if (START_POSITION + (PIXEL_WIDTH * i) > *yPos)
        {
            *yPos = i - 1;
            break;
        }

        if (i == Y_PIXEL)
            return false;
    }

    return true;
}

void OpenListAdd(stNODE* node)
{
    for (NODELIST* nodeList = g_OpenList;;nodeList = nodeList->next)
    {
        if (nodeList->next != nullptr)
            continue;

        nodeList->next = new NODELIST;

        nodeList->next->data = node;
        nodeList->next->prev = nodeList;
        break;
    }
}

void CloseListAdd(stNODE* node)
{
    for (NODELIST* nodeList = g_CloseList;; nodeList = nodeList->next)
    {
        if (nodeList->next != nullptr)
            continue;

        nodeList->next = new NODELIST;

        nodeList->next->data = node;
        nodeList->next->prev = nodeList;
        break;
    }
}

void OpenListDelete(stNODE* node)
{
    for (NODELIST* nodeList = g_OpenList->next;; nodeList = nodeList->next)
    {
        if (nodeList == nullptr)
            return;
        if (nodeList->data != node)
            continue;

        if (nodeList->next != nullptr)
        {
            nodeList->next->prev = nodeList->prev;
        }
        nodeList->prev->next = nodeList->next;

        delete nodeList;

        break;
    }
}

void CloseListDelete(stNODE* node)
{
    for (NODELIST* nodeList = g_CloseList->next;; nodeList = nodeList->next)
    {
        if (nodeList == nullptr)
            return;
        if (nodeList->data != node)
            continue;

        if (nodeList->next != nullptr)
        {
            nodeList->next->prev = nodeList->prev;
        }        
        
        nodeList->prev->next = nodeList->next;

        delete nodeList;
        break;
    }
}

void SortOpenList()
{
    if (g_OpenList->next == nullptr)
        return;

    int size = 0;

    for (NODELIST* nodeList = g_OpenList->next; nodeList != nullptr; nodeList = nodeList->next)
    {
        size++;
    }

    for (int i = 0; i < size; i++)
    {
        for (NODELIST* nodeList2 = g_OpenList->next; nodeList2->next != nullptr; nodeList2 = nodeList2->next)
        {
            if (nodeList2->data->F > nodeList2->next->data->F)
            {
                stNODE* temp = nodeList2->data;
                nodeList2->data = nodeList2->next->data;
                nodeList2->next->data = temp;
            }
        }
    }
}

bool SetGHF(stNODE* node, bool extra)
{
    if (node->prev == nullptr)
        return false;

    if (extra)
        node->G = node->prev->G + 1.5f;
    else
        node->G = node->prev->G + 1;


    int Xdistance = node->Xpos - g_EndNode->Xpos;
    if (Xdistance < 0)
        Xdistance *= -1;

    int Ydistance = node->Ypos - g_EndNode->Ypos;
    if (Ydistance < 0)
        Ydistance *= -1;

    node->H = Xdistance + Ydistance;
    node->F = node->G + node->H;
    return true;
}

void PathFind()
{
    if (g_StartNode == nullptr || g_EndNode == nullptr)
        return;

    int Xdistance = g_StartNode->Xpos - g_EndNode->Xpos;
    if (Xdistance < 0)
        Xdistance *= -1;

    int Ydistance = g_StartNode->Ypos - g_EndNode->Ypos;
    if (Ydistance < 0)
        Ydistance *= -1;

    g_StartNode->G = 0;
    g_StartNode->H = Xdistance + Ydistance;
    g_StartNode->F = g_StartNode->G + g_StartNode->H;

    stNODE* currentNode = g_StartNode;
    OpenListAdd(currentNode);
    for (;;)
    {
        
        //OpenListAdd(currentNode);
        //오픈리스트를 열고자하는 곳에 장애물이 없거나 버퍼를 벗어나지 않았거나 열려있는 상태가 아니거나 닫혀있는 상태가 아닌경우
        if (currentNode->Xpos + 1 < X_PIXEL &&
            (g_ScreenBuffer[currentNode->Xpos + 1][currentNode->Ypos] == NOTHING || g_ScreenBuffer[currentNode->Xpos + 1][currentNode->Ypos] == ENDPOINT))
        {
            stNODE* newOpenNode = new stNODE;
            newOpenNode->Xpos = currentNode->Xpos + 1;
            newOpenNode->Ypos = currentNode->Ypos;
            newOpenNode->prev = currentNode;
            g_ScreenBuffer[newOpenNode->Xpos][newOpenNode->Ypos] = ISOPEN;
            SetGHF(newOpenNode, false);
            OpenListAdd(newOpenNode);
        }

        if (currentNode->Xpos + 1 < X_PIXEL && currentNode->Ypos + 1 < Y_PIXEL &&
            (g_ScreenBuffer[currentNode->Xpos + 1][currentNode->Ypos + 1] == NOTHING || g_ScreenBuffer[currentNode->Xpos + 1][currentNode->Ypos + 1] == ENDPOINT))
        {
            stNODE* newOpenNode = new stNODE;
            newOpenNode->Xpos = currentNode->Xpos + 1;
            newOpenNode->Ypos = currentNode->Ypos + 1;
            newOpenNode->prev = currentNode;
            g_ScreenBuffer[newOpenNode->Xpos][newOpenNode->Ypos] = ISOPEN;
            SetGHF(newOpenNode, true);
            OpenListAdd(newOpenNode);
        }

        if (currentNode->Ypos + 1 < Y_PIXEL &&
            (g_ScreenBuffer[currentNode->Xpos][currentNode->Ypos + 1] == NOTHING || g_ScreenBuffer[currentNode->Xpos][currentNode->Ypos + 1] == ENDPOINT))
        {
            stNODE* newOpenNode = new stNODE;
            newOpenNode->Xpos = currentNode->Xpos;
            newOpenNode->Ypos = currentNode->Ypos + 1;
            newOpenNode->prev = currentNode;
            g_ScreenBuffer[newOpenNode->Xpos][newOpenNode->Ypos] = ISOPEN;
            SetGHF(newOpenNode, false);
            OpenListAdd(newOpenNode);
        }

        if (currentNode->Ypos + 1 < Y_PIXEL && currentNode->Xpos - 1 >= 0 &&
            (g_ScreenBuffer[currentNode->Xpos - 1][currentNode->Ypos + 1] == NOTHING || g_ScreenBuffer[currentNode->Xpos - 1][currentNode->Ypos + 1] == ENDPOINT))
        {
            stNODE* newOpenNode = new stNODE;
            newOpenNode->Xpos = currentNode->Xpos - 1;
            newOpenNode->Ypos = currentNode->Ypos + 1;
            newOpenNode->prev = currentNode;
            g_ScreenBuffer[newOpenNode->Xpos][newOpenNode->Ypos] = ISOPEN;
            SetGHF(newOpenNode, true);
            OpenListAdd(newOpenNode);
        }

        if (currentNode->Xpos - 1 >= 0 &&
            (g_ScreenBuffer[currentNode->Xpos - 1][currentNode->Ypos] == NOTHING || g_ScreenBuffer[currentNode->Xpos - 1][currentNode->Ypos] == ENDPOINT))
        {
            stNODE* newOpenNode = new stNODE;
            newOpenNode->Xpos = currentNode->Xpos - 1;
            newOpenNode->Ypos = currentNode->Ypos;
            newOpenNode->prev = currentNode;
            g_ScreenBuffer[newOpenNode->Xpos][newOpenNode->Ypos] = ISOPEN;
            SetGHF(newOpenNode, false);
            OpenListAdd(newOpenNode);
        }

        if (currentNode->Xpos - 1 >= 0 && currentNode->Ypos - 1 >= 0 &&
            (g_ScreenBuffer[currentNode->Xpos - 1][currentNode->Ypos - 1] == NOTHING || g_ScreenBuffer[currentNode->Xpos - 1][currentNode->Ypos - 1] == ENDPOINT))
        {
            stNODE* newOpenNode = new stNODE;
            newOpenNode->Xpos = currentNode->Xpos - 1;
            newOpenNode->Ypos = currentNode->Ypos - 1;
            newOpenNode->prev = currentNode;
            g_ScreenBuffer[newOpenNode->Xpos][newOpenNode->Ypos] = ISOPEN;
            SetGHF(newOpenNode, true);
            OpenListAdd(newOpenNode);
        }

        if (currentNode->Ypos - 1 >= 0 &&
            (g_ScreenBuffer[currentNode->Xpos][currentNode->Ypos - 1] == NOTHING || g_ScreenBuffer[currentNode->Xpos][currentNode->Ypos - 1] == ENDPOINT))
        {
            stNODE* newOpenNode = new stNODE;
            newOpenNode->Xpos = currentNode->Xpos;
            newOpenNode->Ypos = currentNode->Ypos - 1;
            newOpenNode->prev = currentNode;
            g_ScreenBuffer[newOpenNode->Xpos][newOpenNode->Ypos] = ISOPEN;
            SetGHF(newOpenNode, false);
            OpenListAdd(newOpenNode);
        }

        if (currentNode->Xpos + 1 < X_PIXEL && currentNode->Ypos - 1 >= 0 &&
            (g_ScreenBuffer[currentNode->Xpos + 1][currentNode->Ypos - 1] == NOTHING || g_ScreenBuffer[currentNode->Xpos + 1][currentNode->Ypos - 1] == ENDPOINT))
        {
            stNODE* newOpenNode = new stNODE;
            newOpenNode->Xpos = currentNode->Xpos + 1;
            newOpenNode->Ypos = currentNode->Ypos - 1;
            newOpenNode->prev = currentNode;
            g_ScreenBuffer[newOpenNode->Xpos][newOpenNode->Ypos] = ISOPEN;
            SetGHF(newOpenNode, true);
            OpenListAdd(newOpenNode);
        }

        CloseListAdd(currentNode);
        g_ScreenBuffer[currentNode->Xpos][currentNode->Ypos] = ISCLOSE;

        for (NODELIST* ptr = g_OpenList->next; ptr != nullptr; ptr = ptr->next)
        {
            printf("%f\n", ptr->data->F);
        }
        printf("대입끝/////////////////////\n");

        OpenListDelete(currentNode);
        //오름차순으로 정렬
        SortOpenList();

        for (NODELIST* ptr = g_OpenList->next; ptr != nullptr; ptr = ptr->next)
        {
            printf("Xpos %d Ypos %d F값 %f\n",ptr->data->Xpos, ptr->data->Ypos, ptr->data->F);
        }
        printf("소팅끝/////////////////////\n");
        //맨 처음 노드가 가장 F값이 작은 노드 -> currentNode 넣는다
        currentNode = g_OpenList->next->data;

        if (currentNode->Xpos == g_EndNode->Xpos && currentNode->Ypos == g_EndNode->Ypos)
        {

        }
            return;

    }

    return;
}